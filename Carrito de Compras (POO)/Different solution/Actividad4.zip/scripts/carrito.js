class Carrito {

  #currency;
  #products;
  #units;

  constructor({currency, products}) {
    this.#currency = currency;
    this.#products = products;
    this.#units = {};
  }

  updateProduct(sku, unit) {
    // Actualiza el número de unidades que se quieren comprar de un producto
    const u = Number(unit);
    if (u > 0) {
      this.#units[sku] = u;
    } else {
      delete this.#units[sku];
    }
  }

  getProductUnits(sku) {
    if (!Object.keys(this.#units).includes(sku)) {
      return 0
    } else {
      return this.#units[sku];
    }
  }

  getProductTotal(sku) {
    let ret = 0;
    if (Object.keys(this.#units).includes(sku)) {
      ret = Number(this.#units[sku] * this.getProduct(sku).price).toFixed(2)
    }
    return ret;
  }

  getProduct(sku) {
    return this.#products.find(p => p.sku === sku);
  }

  get ticket() {
    const products = Object.keys(this.#units).map(sku => {
      return {
        ...this.getProduct(sku),
        total: Number(this.getProductTotal(sku))
      }
    });
    return {
      currency: this.#currency,
      products
    };
  }

  get products () {
    return this.#products
  }

  get currency () {
    return this.#currency;
  }
}
