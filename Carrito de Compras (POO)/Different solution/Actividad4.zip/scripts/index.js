const API = "https://jsonblob.com/api/jsonBlob/993897932361318400";
const info = fetch(API).then(json => json.json());

document.addEventListener('DOMContentLoaded', () => {
    const carritoView = new CarritoView(document.querySelector('#carrito'));
    info.then(res => {
        carritoView.init(res);
    })
});