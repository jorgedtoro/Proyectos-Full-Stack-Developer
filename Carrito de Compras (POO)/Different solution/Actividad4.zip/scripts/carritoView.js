const carritoRowTemplate = ({title, sku, price, currency, units, total}) => {
  return `
    <tr class="list__row" data-carrito-sku=${sku}>
      <td class="list__row-cell">
        <p class="list__title">${title}</p>
        <p class="list__sku">Ref: ${sku}</p>
      </td>
      <td class="list__row-cell">
        <button class="list__control" data-carrito-action="sub">-</button>
        <input type="number" class="list__control-number" value="${units}" data-carrito-action="set" data-carrito-units>
        <button class="list__control" data-carrito-action="add">+</button>
      </td>
      <td class="list__row-cell">
        <span class="list__price">${price}${currency}</span>
      </td>
      <td class="list__row-cell">
        <span class="list__price" data-carrito-product-total>${total}${currency}</span>
      </td>
    </tr>`;
};

const totalProductRowTemplate = ({title, total, currency}) => {
  return `
    <tr>
      <td>
        ${title}
      </td>
      <td>
        ${total}${currency}
      </td>
    </tr>`;
};

class CarritoView {

  #element;
  #carrito;
  #elProducts;
  #elTotal;
  #elTotalProducts;

  constructor(element) {
    this.#element = element;
    this.#elProducts = this.#element.querySelector("#carrito-w-products");
    this.#elTotalProducts = this.#element.querySelector("#carrito-w-total-products");
    this.#elTotal = this.#element.querySelector("#carrito-w-total");
  }

  init(info) {
    this.#carrito = new Carrito(info);
    this.#productsFirstPaint();
    this.#totalPaint();
  }

  #controlHandler(event) {
    const control = event.target;
    const row = control.closest("[data-carrito-sku]");
    const sku = row.dataset.carritoSku;
    const action = control.dataset.carritoAction;
    let units;

    switch (action) {
      case "add":
        units = this.#carrito.getProductUnits(sku);
        units++;
        break;
      case "sub":
        units = this.#carrito.getProductUnits(sku);
        units = units > 0 ? units - 1 : 0;
        break;
      case "set":
        units = control.value;
        break;
    }

    this.#carrito.updateProduct(sku, units);

    // Update view
    row.querySelector("[data-carrito-units]").value = units;
    row.querySelector("[data-carrito-product-total]").innerHTML = `${this.#carrito.getProductTotal(sku)}${this.#carrito.currency}`;
    this.#totalPaint();
  }

  #productsFirstPaint() {
    let res = "";
    const currency = this.#carrito.currency;
    this.#carrito.products.forEach(product => {
      res += carritoRowTemplate({currency: currency, total: 0, units: 0, ...product});
    });
    this.#elProducts.innerHTML = res;

    const handlerDictionary = {
      button: "click",
      input: "change"
    };

    this.#elProducts.querySelectorAll("[data-carrito-action]").forEach(control => {
      control.addEventListener(handlerDictionary[control.tagName.toLowerCase()], this.#controlHandler.bind(this));
    });
  }

  #totalPaint() {
    const {products, currency} = this.#carrito.ticket;

    this.#elTotalProducts.innerHTML = products.reduce((acc, product) => 
      acc + totalProductRowTemplate({...product, currency })
    , "");

    const total = products.reduce((acc, product) => acc + product.total, 0);
    this.#elTotal.innerHTML = `${Number(total).toFixed(2)}${currency}`;
  }
}