export interface Post {
  id: number;
  title: string;
  url: string;
  body: string;
  date: string;
}
