import { Post } from "../interfaces/post.interface";

export const PUBLICACIONES: Post[] = [
  {
    id: 1,
    title: 'En un lugar de la mancha',
    url: 'https://ichef.bbci.co.uk/news/800/cpsprodpb/15665/production/_107435678_perro1.jpg.webp',
    body: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur expedita aut obcaecati iste veniam. Consequuntur, unde. Maiores quasi quos ea repellat nemo, ab ipsum fugiat, est non harum excepturi voluptate.',
    date: '2022-07-18'
  },
  {
    id: 2,
    title: 'Solo se que no se nada',
    url: 'https://pymstatic.com/62740/conversions/rene-descartes-wide.jpg',
    body: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur expedita aut obcaecati iste veniam. Consequuntur, unde. Maiores quasi quos ea repellat nemo, ab ipsum fugiat, est non harum excepturi voluptate.',
    date: '2022-07-19'
  }

]
