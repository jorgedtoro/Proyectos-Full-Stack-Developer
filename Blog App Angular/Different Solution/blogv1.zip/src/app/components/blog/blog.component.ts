import { Component, OnInit } from '@angular/core';
import { PUBLICACIONES } from 'src/app/db/publicaciones.db';
import { Post } from 'src/app/interfaces/post.interface';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  arrPost: Post[] = [];
  id: number = 3;
  viewBlog: string = "";
  newPost: any;
  constructor() {
    this.newPost = {
      title: "",
      url: "",
      body: "",
      date: ""
    }
    this.arrPost = PUBLICACIONES

  }

  ngOnInit(): void {
    this.viewBlog = this.getPost()
  }

  getDataForm(): void {
    if (this.newPost.title !== "" && this.newPost.date !== "" && this.newPost.url !== "" && this.newPost.body !== "") {
      let nuevoPost: Post = { id: this.id, ...this.newPost }
      this.arrPost.push(nuevoPost);
      //igualamos la variable que se pinta al nuevo resultado del array
      this.viewBlog = this.getPost();
      this.id++;
      this.newPost = {
        title: "",
        url: "",
        body: "",
        date: ""
      }
    } else {
      alert('Todos los campos son obligatorios')
    }

  }

  getPost(): string {

    let result = ""
    this.arrPost = this.arrPost.sort((a, b) => b.id - a.id)
    this.arrPost.forEach(post => {
      result += `<article>
                <h3>${post.title}</h3>
                <hr>
                <figure>
                  <img src="${post.url}" alt="${post.title}">
                </figure>
                <div>
                  ${post.body}
                </div>
                <small>${post.date}</small>
      </article>`
    })
    return result;
  }

}
